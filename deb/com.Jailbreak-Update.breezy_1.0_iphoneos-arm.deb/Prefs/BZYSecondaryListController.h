#import <Preferences/PSListController.h>
#import <TitanD3vUniversal/TitanD3vUniversal.h>

@interface BZYGestureController : TDSecondaryController
@end

