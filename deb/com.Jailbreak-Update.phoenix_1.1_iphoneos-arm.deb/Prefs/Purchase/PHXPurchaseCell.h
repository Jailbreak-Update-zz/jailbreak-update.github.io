#import <UIKit/UIKit.h>
#import <TitanD3vUniversal/TitanD3vUniversal.h>

@interface PHXPurchaseCell : UICollectionViewCell
@property (nonatomic, retain) BlurBannerView *baseView;
@property (nonatomic, retain) UIImageView *screenshotImage;
@end