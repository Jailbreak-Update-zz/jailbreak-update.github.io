#import <TitanD3vUniversal/TitanD3vUniversal.h>

@interface CategoriesIconCell : UICollectionViewCell
@property (nonatomic, retain) UIView *baseView;
@property (nonatomic, retain) UIImageView *iconImage;
@end
