#import "ContactsData.h"

@implementation ContactsData
@end
