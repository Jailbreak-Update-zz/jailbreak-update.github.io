#import <TitanD3vUniversal/TitanD3vUniversal.h>

@interface MessageView : UIView
@property (nonatomic, retain) UIImageView *icon;
@property (nonatomic, retain) UILabel *title;
@end

